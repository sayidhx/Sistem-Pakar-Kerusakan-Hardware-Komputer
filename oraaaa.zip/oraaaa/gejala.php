<!DOCTYPE html>
<html>
<head>
    <title>CRUD Data Gejala</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php
include 'config.php';

if (!is_logged_in()) {
    redirect_to_login();
}
?>

<div class="topnav">
    <a class="active" href="dashboard.php">Dashboard</a>
    <a href="hardware.php">Data Hardware</a>
    <a href="gejala.php">Data Gejala</a>
    <a href="solusi.php">Data Solusi</a>
    <a href="logout.php">Logout</a>
</div>



<h1>Data Gejala</h1>

<?php
// Handle Create, Update, Delete for gejala
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_gejala'])) {
    $kode_hardware = $_POST['kode_hardware'];
    $gejala = $_POST['gejala'];
    $sql = "INSERT INTO gejala (kode_hardware, gejala) VALUES ('$kode_hardware', '$gejala')";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil ditambahkan</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_gejala'])) {
    $id = $_POST['id'];
    $kode_hardware = $_POST['kode_hardware'];
    $gejala = $_POST['gejala'];
    $sql = "UPDATE gejala SET kode_hardware='$kode_hardware', gejala='$gejala' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil diperbarui</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_gejala'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM gejala WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil dihapus</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}
?>

<div class="form-container">
    <h2>Tambah Data Gejala</h2>
    <form method="post">
        <label>Kode Hardware:</label>
        <input type="text" name="kode_hardware" required>
        <label>Gejala:</label>
        <input type="text" name="gejala" required>
        <input type="submit" name="create_gejala" value="Tambah">
    </form>

    <h2>Perbarui Data Gejala</h2>
    <form method="post">
        <label>ID:</label>
        <input type="text" name="id" required>
        <label>Kode Hardware:</label>
        <input type="text" name="kode_hardware" required>
        <label>Gejala:</label>
        <input type="text" name="gejala" required>
        <input type="submit" name="update_gejala" value="Perbarui">
    </form>

    <h2>Hapus Data Gejala</h2>
    <form method="post">
        <label>ID:</label>
        <input type="text" name="id" required>
        <input type="submit" name="delete_gejala" value="Hapus">
    </form>

    <h2>Data Gejala</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Kode Hardware</th>
            <th>Gejala</th>
        </tr>
        <?php
        $sql = "SELECT * FROM gejala";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["id"]. "</td><td>" . $row["kode_hardware"]. "</td><td>" . $row["gejala"]. "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='3'>0 results</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>

<?php
$conn->close();
?>
