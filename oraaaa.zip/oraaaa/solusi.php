<!DOCTYPE html>
<html>
<head>
    <title>CRUD Data Solusi</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php
include 'config.php';

if (!is_logged_in()) {
    redirect_to_login();
}
?>

<div class="topnav">
    <a class="active" href="dashboard.php">Dashboard</a>
    <a href="hardware.php">Data Hardware</a>
    <a href="gejala.php">Data Gejala</a>
    <a href="solusi.php">Data Solusi</a>
    <a href="logout.php">Logout</a>
</div>



<h1>Data Solusi</h1>

<?php
// Handle Create, Update, Delete for solusi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_solusi'])) {
    $id_gejala = $_POST['id_gejala'];
    $solusi = $_POST['solusi'];
    $sql = "INSERT INTO solusi (id_gejala, solusi) VALUES ('$id_gejala', '$solusi')";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil ditambahkan</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_solusi'])) {
    $id = $_POST['id'];
    $id_gejala = $_POST['id_gejala'];
    $solusi = $_POST['solusi'];
    $sql = "UPDATE solusi SET id_gejala='$id_gejala', solusi='$solusi' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil diperbarui</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_solusi'])) {
    $id = $_POST['id'];
    $sql = "DELETE FROM solusi WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil dihapus</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}
?>

<div class="form-container">
    <h2>Tambah Data Solusi</h2>
    <form method="post">
        <label>ID Gejala:</label>
        <input type="text" name="id_gejala" required>
        <label>Solusi:</label>
        <input type="text" name="solusi" required>
        <input type="submit" name="create_solusi" value="Tambah">
    </form>

    <h2>Perbarui Data Solusi</h2>
    <form method="post">
        <label>ID:</label>
        <input type="text" name="id" required>
        <label>ID Gejala:</label>
        <input type="text" name="id_gejala" required>
        <label>Solusi:</label>
        <input type="text" name="solusi" required>
        <input type="submit" name="update_solusi" value="Perbarui">
    </form>

    <h2>Hapus Data Solusi</h2>
    <form method="post">
        <label>ID:</label>
        <input type="text" name="id" required>
        <input type="submit" name="delete_solusi" value="Hapus">
    </form>

    <h2>Data Solusi</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>ID Gejala</th>
            <th>Solusi</th>
        </tr>
        <?php
        $sql = "SELECT * FROM solusi";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["id"]. "</td><td>" . $row["id_gejala"]. "</td><td>" . $row["solusi"]. "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='3'>0 results</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>

<?php
$conn->close();
?>
