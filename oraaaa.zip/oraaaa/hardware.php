<!DOCTYPE html>
<html>
<head>
    <title>CRUD Data Hardware</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php
include 'config.php';

if (!is_logged_in()) {
    redirect_to_login();
}
?>

<div class="topnav">
    <a class="active" href="dashboard.php">Dashboard</a>
    <a href="hardware.php">Data Hardware</a>
    <a href="gejala.php">Data Gejala</a>
    <a href="solusi.php">Data Solusi</a>
    <a href="logout.php">Logout</a>
</div>




<h1>Data Hardware</h1>

<?php
// Handle Create, Update, Delete for data_hardware
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_hardware'])) {
    $kode = $_POST['kode'];
    $nama_hardware = $_POST['nama_hardware'];
    $sql = "INSERT INTO data_hardware (kode, nama_hardware) VALUES ('$kode', '$nama_hardware')";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil ditambahkan</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_hardware'])) {
    $kode = $_POST['kode'];
    $nama_hardware = $_POST['nama_hardware'];
    $sql = "UPDATE data_hardware SET nama_hardware='$nama_hardware' WHERE kode='$kode'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil diperbarui</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_hardware'])) {
    $kode = $_POST['kode'];
    $sql = "DELETE FROM data_hardware WHERE kode='$kode'";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Data berhasil dihapus</div>";
    } else {
        echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}
?>

<div class="form-container">
    <h2>Tambah Data Hardware</h2>
    <form method="post">
        <label>Kode:</label>
        <input type="text" name="kode" required>
        <label>Nama Hardware:</label>
        <input type="text" name="nama_hardware" required>
        <input type="submit" name="create_hardware" value="Tambah">
    </form>

    <h2>Perbarui Data Hardware</h2>
    <form method="post">
        <label>Kode:</label>
        <input type="text" name="kode" required>
        <label>Nama Hardware:</label>
        <input type="text" name="nama_hardware" required>
        <input type="submit" name="update_hardware" value="Perbarui">
    </form>

    <h2>Hapus Data Hardware</h2>
    <form method="post">
        <label>Kode:</label>
        <input type="text" name="kode" required>
        <input type="submit" name="delete_hardware" value="Hapus">
    </form>

    <h2>Data Hardware</h2>
    <table>
        <tr>
            <th>Kode</th>
            <th>Nama Hardware</th>
        </tr>
        <?php
        $sql = "SELECT * FROM data_hardware";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["kode"]. "</td><td>" . $row["nama_hardware"]. "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>0 results</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>

<?php
$conn->close();
?>
