document.addEventListener('DOMContentLoaded', function() {
    const hardwareOptions = document.querySelectorAll('.hardware-option');

    hardwareOptions.forEach(function(option) {
        option.addEventListener('click', function() {
            const checkbox = this.querySelector('input[type="checkbox"]');
            checkbox.checked = !checkbox.checked;
            if (checkbox.checked) {
                this.classList.add('checked');
            } else {
                this.classList.remove('checked');
            }
        });
    });
});
