<?php include('../config/database.php'); ?>
<?php include('../includes/header.php'); ?>

<h2>Pilih Hardware</h2>
<form action="select_gejala.php" method="GET" onsubmit="return validateHardwareForm();">
    <div class="hardware-options">
        <?php
        $query = "SELECT * FROM data_hardware";
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            echo "<div class='hardware-option'><label><input type='checkbox' name='hardware[]' value='{$row['kode']}'>{$row['nama_hardware']}</label></div>";
        }            
        ?>
        <br>
    </div>
    <button type="submit">Lanjut</button>
</form>

<script>
    function validateHardwareForm() {
        const checkboxes = document.querySelectorAll('input[name="hardware[]"]');
        let checked = false;
        checkboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                checked = true;
            }
        });
        if (!checked) {
            alert('Silakan pilih setidaknya satu hardware.');
            return false;
        }
        return true;
    }

    document.addEventListener('DOMContentLoaded', function() {
        const hardwareOptions = document.querySelectorAll('.hardware-option');

        hardwareOptions.forEach(function(option) {
            option.addEventListener('click', function() {
                const checkbox = this.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                if (checkbox.checked) {
                    this.classList.add('checked');
                } else {
                    this.classList.remove('checked');
                }
            });
        });
    });
</script>

<?php include('../includes/footer.php'); ?>
