<?php include('../config/database.php'); ?>
<?php include('../includes/header.php'); ?>

<?php
if (!isset($_GET['hardware']) || empty($_GET['hardware'])) {
    echo "<h2>Silakan pilih setidaknya satu hardware.</h2>";
    echo "<a href='home.php'>Kembali</a>";
    include('../includes/footer.php');
    exit();
}

$hardware_kodes = $_GET['hardware'];
$hardware_kodes_str = implode("','", $hardware_kodes);

// Ambil data hardware yang dipilih
$query_hardware = "SELECT * FROM data_hardware WHERE kode IN ('$hardware_kodes_str')";
$result_hardware = $conn->query($query_hardware);

// Ambil data gejala yang sesuai dengan hardware yang dipilih
$query_gejala = "SELECT * FROM gejala WHERE kode_hardware IN ('$hardware_kodes_str')";
$result_gejala = $conn->query($query_gejala);

$hardware_gejala = [];
while ($row_gejala = $result_gejala->fetch_assoc()) {
    $hardware_gejala[$row_gejala['kode_hardware']][] = $row_gejala;
}
?>

<form action="show_solution.php" method="POST" onsubmit="return validateGejalaForm();">
    <?php while ($row_hardware = $result_hardware->fetch_assoc()) : ?>
        <div class="hardware-section">
            <h2>Hardware yang Dipilih</h2>
            <h3><?= $row_hardware['nama_hardware'] ?></h3>
            <div class="gejala-section">
                <h2>Pilih Gejala</h2><br>
                <?php if (isset($hardware_gejala[$row_hardware['kode']])) : ?>
                    <?php foreach ($hardware_gejala[$row_hardware['kode']] as $gejala) : ?>
                        <div class="gejala-option">
                            <label>
                                <input type="checkbox" name="gejala[]" value="<?= $gejala['id'] ?>">
                                <?= $gejala['gejala'] ?>
                            </label>
                        </div><br>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p>Tidak ada gejala yang tersedia untuk hardware ini.</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endwhile; ?>
    <a href="home.php" class="btn-back">Kembali</a>
    <button type="submit">Lihat Solusi</button>
</form>

<script>
    function validateGejalaForm() {
        const checkboxes = document.querySelectorAll('input[name="gejala[]"]');
        let checked = false;
        checkboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                checked = true;
            }
        });
        if (!checked) {
            alert('Silakan pilih setidaknya satu gejala.');
            return false;
        }
        return true;
    }

    document.addEventListener('DOMContentLoaded', function() {
        const gejalaOptions = document.querySelectorAll('.gejala-option');

        gejalaOptions.forEach(function(option) {
            option.addEventListener('click', function() {
                const checkbox = this.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                if (checkbox.checked) {
                    this.classList.add('checked');
                } else {
                    this.classList.remove('checked');
                }
            });
        });
    });
</script>

<?php include('../includes/footer.php'); ?>
