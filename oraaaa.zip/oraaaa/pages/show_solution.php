<?php include('../config/database.php'); ?>
<?php include('../includes/header.php'); ?>

<?php
$gejala_ids = $_POST['gejala'];
$gejala_ids_str = implode(",", $gejala_ids);
$query = "SELECT g.gejala, s.solusi FROM gejala g JOIN solusi s ON g.id = s.id_gejala WHERE g.id IN ($gejala_ids_str)";
$result = $conn->query($query);
?>

<h2>Gejala/Solusi</h2>
<div class="solusi-list">
    <?php while ($row = $result->fetch_assoc()) : ?>
        <div class="solusi-item">
            <p><strong>Gejala:</strong> <?= htmlspecialchars($row['gejala'], ENT_QUOTES, 'UTF-8') ?></p>
            <p><strong>Solusi:</strong> <?= htmlspecialchars($row['solusi'], ENT_QUOTES, 'UTF-8') ?></p>
        </div>
    <?php endwhile; ?>
</div>

<a href="home.php" class="btn-back">Mulai Diagnosa Kembali</a>

<!-- WhatsApp Contact Link -->
<div class="contact-whatsapp">
    <p>Jika ada pertanyaan lebih lanjut, hubungi kami melalui <a href="https://wa.me/+628886154110?text=Hallo%20aku%20punya%20pertanyaan%20lebih%20lanjut" target="_blank">WhatsApp</a>.</p>
</div>

<?php include('../includes/footer.php'); ?>
