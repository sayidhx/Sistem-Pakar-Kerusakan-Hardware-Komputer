<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistem_pakar";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

session_start();

function is_logged_in() {
    return isset($_SESSION['username']);
}

function redirect_to_dashboard() {
    header('Location: dashboard.php');
    exit();
}
?>
