<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Sistem Pakar Kerusakan Hardware Komputer</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php
include 'config.php';

if (!is_logged_in()) {
    redirect_to_login();
}
?>

<div class="topnav">
    <a class="active" href="dashboard.php">Dashboard</a>
    <a href="hardware.php">Data Hardware</a>
    <a href="gejala.php">Data Gejala</a>
    <a href="solusi.php">Data Solusi</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">
    <h1>Dashboard</h1>
    <p>Selamat datang di sistem pakar kerusakan hardware komputer.</p>
    
    <h2>Tentang Sistem Pakar Kerusakan Komputer</h2>
    <p>Sistem pakar kerusakan komputer adalah aplikasi yang dirancang untuk membantu pengguna dalam mendiagnosis dan memperbaiki masalah pada hardware komputer. Sistem ini menggunakan pengetahuan yang diperoleh dari para ahli di bidang perbaikan komputer untuk memberikan rekomendasi yang tepat dalam menyelesaikan masalah yang dihadapi oleh pengguna.</p>

    <h3>Fitur Utama:</h3>
    <ul>
        <li>Diagnosa cepat dan akurat untuk berbagai masalah hardware komputer.</li>
        <li>Panduan langkah demi langkah untuk memperbaiki masalah yang terdeteksi.</li>
        <li>Basis data yang luas mencakup berbagai jenis kerusakan dan solusi yang relevan.</li>
        <li>Antarmuka yang mudah digunakan dan intuitif.</li>
    </ul>

    <h3>Keuntungan Menggunakan Sistem Pakar:</h3>
    <ul>
        <li>Meningkatkan efisiensi dalam proses perbaikan hardware komputer.</li>
        <li>Meminimalkan biaya dengan memberikan solusi yang tepat tanpa perlu mengganti komponen yang tidak perlu.</li>
        <li>Meningkatkan kepuasan pengguna dengan memberikan solusi yang cepat dan akurat.</li>
    </ul>

    <p>Sistem pakar ini dikembangkan dengan tujuan untuk membantu teknisi dan pengguna dalam mengidentifikasi dan memperbaiki masalah pada hardware komputer dengan lebih mudah dan efektif.</p>
</div>

</body>
</html>
