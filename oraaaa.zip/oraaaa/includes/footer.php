</main>
        <footer>
            <p>&copy; 2024 Sistem Pakar Kerusakan Hardware Komputer</p>
        </footer>
    </div>
</body>
</html>
